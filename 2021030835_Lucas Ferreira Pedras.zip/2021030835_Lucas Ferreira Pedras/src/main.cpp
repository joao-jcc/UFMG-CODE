#include <iostream>
#include <vector>
#include <array>
#include "../include/dinic.hpp"
#include "../include/edge.hpp"

using namespace std;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int V,E;
    cin >> V >> E;

    // @param V Número de nós (geradores + consumidores)
    // @param E Número de conexões (arestas)
    vector<long long> demand(V+1,0);
    vector<bool> isGenerator(V+1,false);

    long long total_demand=0;

    // Leitura dos nós e definição de geradores e consumidores
    // @param nodeId Identificador do nó atual
    // @param T Tipo do nó: 0 = gerador, >0 = demanda do consumidor
    for(int idx=1; idx<=V; idx++){
        int nodeId; 
        long long T;
        cin >> nodeId >> T;
        if (T==0) {
            isGenerator[nodeId]=true;
        } else {
            demand[nodeId]=T;
            total_demand+=T;
        }
    }

    // Criação do super-sumo (S) e super-fosso (T) para fluxo máximo
    // S: fonte artificial, T: sumidouro artificial
    int S=0, T=V+1;
    Dinic dinic(V+2);

    long long INF = 1000000000LL;

    // Liga geradores ao S e consumidores a T
    // @param i nó atual
    for (int i=1; i<=V; i++){
        if(isGenerator[i]){
            // @param S super-fonte
            // @param i nó gerador
            // @param INF capacidade muito grande (infinita prática)
            dinic.add_edge(S,i,INF);
        } else {
            // @param i nó consumidor
            // @param T super-sumidouro
            // @param demand[i] demanda do consumidor
            dinic.add_edge(i,T,demand[i]);
        }
    }

    vector<int> from(E+1), to_(E+1);
    vector<long long> cap(E+1);
    long long sum_gen_out=0;

    // Leitura das conexões
    // @param Vi nó de origem da aresta
    // @param Vj nó de destino da aresta
    // @param C capacidade da aresta
    for (int e=1; e<=E; e++){
        int Vi,Vj; long long C;
        cin >> Vi >> Vj >> C;
        from[e]=Vi; to_[e]=Vj; cap[e]=C;
        dinic.add_edge(Vi,Vj,C);
        if(isGenerator[Vi]) {
            sum_gen_out += C;
        }
    }

    // Cálculo do fluxo máximo da rede
    long long maxflow = dinic.max_flow(S,T);

    // ETotal: energia total que chega aos consumidores
    // EMissing: energia não atendida (demanda total - atendida)
    // ELoss: energia perdida (energia potencial a partir dos geradores - efetivamente usada)
    long long ETotal = maxflow;
    long long EMissing = total_demand - ETotal;
    if (EMissing<0) EMissing=0;
    long long ELoss = sum_gen_out - ETotal;
    if (ELoss<0) ELoss=0;

    // Identificação de arestas críticas (as que operam no máximo da capacidade)
    vector<array<long long,3>> critical_edges_info; 
    // Formato: {u, v, capacidade_max}
    for (int e=1; e<=E; e++){
        int u = from[e];
        int v = to_[e];
        long long C = cap[e];

        // Verifica no vetor de adjacência qual aresta corresponde a (u,v)
        for (int i=0; i<(int)dinic.adj[u].size(); i++){
            Edge &ed = dinic.adj[u][i];
            if (ed.to==v && ed.original_cap == C) {
                // flow_used = capacidade original - capacidade remanescente
                long long flow_used = ed.original_cap - ed.cap; 
                if (flow_used == ed.original_cap) {
                    critical_edges_info.push_back({(long long)u,(long long)v,C});
                }
                break;
            }
        }
    }

    // Ordenar arestas críticas em ordem decrescente de capacidade
    // Simples bubble sort
    for (int i = 0; i < (int)critical_edges_info.size(); i++) {
        for (int j = i+1; j < (int)critical_edges_info.size(); j++) {
            if (critical_edges_info[j][2] > critical_edges_info[i][2]) {
                array<long long,3> temp = critical_edges_info[i];
                critical_edges_info[i] = critical_edges_info[j];
                critical_edges_info[j] = temp;
            }
        }
    }

    // Saída dos resultados
    cout << ETotal << "\n";
    cout << EMissing << "\n";
    cout << ELoss << "\n";
    cout << (int)critical_edges_info.size() << "\n";
    for (int i=0; i<(int)critical_edges_info.size(); i++) {
        cout << critical_edges_info[i][0] << " " << critical_edges_info[i][1] << " " << critical_edges_info[i][2] << "\n";
    }

    return 0;
}
