#include "../include/dinic.hpp"
#include <queue>


// @param N número de nós no grafo de fluxo
// Construtor da classe Dinic: inicializa vetores auxiliares
Dinic::Dinic(int N) : N(N), adj(N), level(N, -1), it(N, 0) {}

// @param u nó de origem da aresta
// @param v nó de destino da aresta
// @param cap capacidade da aresta (fluxo máximo)
void Dinic::add_edge(int u, int v, long long cap) {
    Edge a{v,(int)adj[v].size(),cap,cap};
    Edge b{u,(int)adj[u].size(),0,0};
    adj[u].push_back(a);
    adj[v].push_back(b);
}

// @param s nó fonte
// @param t nó sumidouro
// Função BFS: constrói níveis no grafo residual
bool Dinic::bfs(int s, int t) {
    std::fill(level.begin(), level.end(), -1);
    level[s] = 0;
    std::queue<int> q;
    q.push(s);

    while(!q.empty()) {
        int u = q.front(); q.pop();
        for(auto &e : adj[u]) {
            // se há capacidade e o nó não foi visitado (level == -1)
            if(e.cap > 0 && level[e.to] == -1) {
                level[e.to] = level[u] + 1;
                q.push(e.to);
            }
        }
    }
    return level[t] != -1;
}

// @param u nó atual
// @param t nó sumidouro
// @param flow fluxo atual possível
// Função sendFlow: envia fluxo pelo caminho bloqueado (DFS)
long long Dinic::sendFlow(int u, int t, long long flow) {
    if(u==t) return flow;
    for (int &idx = it[u]; idx<(int)adj[u].size(); idx++) {
        Edge &e = adj[u][idx];
        // verifica se há capacidade e se o nível do próximo nó é o esperado
        if(e.cap>0 && level[e.to] == level[u]+1) {
            long long curr_flow = (flow < e.cap)? flow : e.cap;
            long long temp_flow = sendFlow(e.to,t,curr_flow);
            if (temp_flow>0) {
                // atualiza capacidades residual e reversa
                e.cap -= temp_flow;
                adj[e.to][e.rev].cap += temp_flow;
                return temp_flow;
            }
        }
    }
    return 0;
}

// @param s nó fonte
// @param t nó sumidouro
// max_flow: Calcula o fluxo máximo utilizando Dinic
long long Dinic::max_flow(int s, int t) {
    long long total = 0;
    // Enquanto houver um caminho de aumento (bfs)
    while(bfs(s, t)) {
        std::fill(it.begin(), it.end(), 0);
        // Envía fluxos enquanto for possível
        while(long long flow = sendFlow(s, t, 1e18)) {
            total += flow;
        }
    }
    return total;
}
