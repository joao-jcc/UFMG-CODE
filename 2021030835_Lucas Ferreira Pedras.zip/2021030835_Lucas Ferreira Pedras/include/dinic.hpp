#ifndef DINIC_HPP
#define DINIC_HPP

#include <vector>
#include "edge.hpp"

class Dinic {
public:
   // @param N número de nós no grafo
    int N;
    // adj: lista de adjacência com arestas
    std::vector<std::vector<Edge>> adj;
    // level: vetor de níveis
    std::vector<int> level;
    // it: vetor de índices para iteração no DFS
    std::vector<int> it;

    Dinic(int N);
    // @param u nó origem
    // @param v nó destino
    // @param cap capacidade da aresta
    void add_edge(int u, int v, long long cap);
    // @param s nó fonte
    // @param t nó sumidouro
    bool bfs(int s, int t);
    // @param u nó atual
    // @param t nó sumidouro
    // @param flow fluxo atual a enviar
    long long sendFlow(int u, int t, long long flow);
    // @param s nó fonte
    // @param t nó sumidouro
    long long max_flow(int s, int t);
};

#endif // DINIC_HPP
