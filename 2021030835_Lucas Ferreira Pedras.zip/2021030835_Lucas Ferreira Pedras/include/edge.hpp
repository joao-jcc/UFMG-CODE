#ifndef EDGE_HPP
#define EDGE_HPP
// Estrutura da aresta no grafo de fluxo
// @param to nó destino
// @param rev índice da aresta reversa
// @param cap capacidade residual atual
// @param original_cap capacidade original da aresta


struct Edge {
    int to, rev;
    long long cap;
    long long original_cap;
};


#endif // EDGE_HPP