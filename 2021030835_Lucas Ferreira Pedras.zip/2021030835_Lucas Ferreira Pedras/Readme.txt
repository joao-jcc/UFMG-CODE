O trabalho está modularizado e utilizando o makefile com as tags e parametros passados pelo monitor Otávio
sendo necessário apenas o comando make para gerar o executável tp2.
A documentação está com 6 páginas apenas pela capa que inclui , sendo de conteúdo as 5 de especificação.